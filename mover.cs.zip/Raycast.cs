using UnityEngine;

public class Raycast : MonoBehaviour
{
    Ray raio;
    RaycastHit hit;
    public Camera tela;


    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Mouse0))
        {
            raio = Camera.main.ScreenPointToRay(Input.mousePosition);
        }

        void hitou (Ray ray, Vector3 ponto)
        {
            if(Physics.Raycast(ray, out hit))
            {
                GameObject esfera = hit.transform.gameObject;
            }
        }
    }
}
